package com.philasecret.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val API = "http://10.0.2.2:8080"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PhilaSecretApp() }
    }
}

class ChatViewModel : ViewModel() {
    private val crypto = CryptoManager()
    private val api = ApiClient(API)
    var username by mutableStateOf("")
    var recipient by mutableStateOf("")
    var message by mutableStateOf("")
    var readOnce by mutableStateOf(true)
    var loggedIn by mutableStateOf(false)
    var status by mutableStateOf("")
    var inbox by mutableStateOf<List<UiMessage>>(emptyList())
    private val scope = kotlinx.coroutines.CoroutineScope(Dispatchers.Main)

    fun register() = scope.launch {
        runCatching {
            withContext(Dispatchers.IO) { api.register(username.trim(), crypto.publicKeyB64()) }
            loggedIn = true
            status = "Compte sécurisé créé."
        }.onFailure { status = it.message ?: "Erreur" }
    }

    fun send() = scope.launch {
        runCatching {
            val to = recipient.trim()
            val text = message
            require(username.isNotBlank() && to.isNotBlank() && text.isNotBlank())
            withContext(Dispatchers.IO) {
                val pk = api.publicKey(to)
                val env = crypto.encrypt(text, pk)
                api.send(username, to, env, readOnce)
            }
            message = ""
            status = "Message chiffré envoyé."
        }.onFailure { status = it.message ?: "Erreur d'envoi" }
    }

    fun refresh() = scope.launch {
        runCatching {
            val rows = withContext(Dispatchers.IO) { api.inbox(username) }
            inbox = rows.map { row ->
                val clear = crypto.decrypt(row.envelope)
                if (row.readOnce) withContext(Dispatchers.IO) { api.delete(row.id) }
                UiMessage(row.id, row.sender, clear, row.readOnce)
            }
        }.onFailure { status = it.message ?: "Erreur de réception" }
    }
}

data class UiMessage(val id: String, val sender: String, val text: String, val readOnce: Boolean)

@Composable
fun PhilaSecretApp(vm: ChatViewModel = viewModel()) {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            if (!vm.loggedIn) RegisterScreen(vm) else ChatScreen(vm)
        }
    }
}

@Composable
fun RegisterScreen(vm: ChatViewModel) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("PhilaSecret", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(8.dp))
        Text("Messagerie privée • messages éphémères")
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(vm.username, { vm.username = it }, label = { Text("Nom d'utilisateur") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button(onClick = vm::register, modifier = Modifier.fillMaxWidth()) { Text("Créer mon identité sécurisée") }
        Spacer(Modifier.height(12.dp))
        Text(vm.status)
    }
}

@Composable
fun ChatScreen(vm: ChatViewModel) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("@${vm.username}", style = MaterialTheme.typography.titleLarge)
            TextButton(onClick = vm::refresh) { Text("Actualiser") }
        }
        HorizontalDivider()
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(vm.recipient, { vm.recipient = it }, label = { Text("Destinataire") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(vm.message, { vm.message = it }, label = { Text("Message") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(vm.readOnce, { vm.readOnce = it })
            Text("Supprimer après lecture")
        }
        Button(onClick = vm::send, modifier = Modifier.fillMaxWidth()) { Text("Envoyer chiffré") }
        Spacer(Modifier.height(8.dp))
        Text(vm.status)
        Spacer(Modifier.height(8.dp))
        Text("Messages reçus", style = MaterialTheme.typography.titleMedium)
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.inbox) { item ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text("De @${item.sender}")
                        Text(item.text)
                        if (item.readOnce) Text("✓ supprimé du serveur après lecture", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }
}
