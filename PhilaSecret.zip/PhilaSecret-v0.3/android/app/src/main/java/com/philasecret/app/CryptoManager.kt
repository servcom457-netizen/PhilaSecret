package com.philasecret.app

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PublicKey
import java.security.spec.X509EncodedKeySpec
import java.util.Base64
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * MVP crypto envelope.
 * Private RSA key never leaves Android Keystore.
 * For production, replace with an audited messaging protocol with ratcheting.
 */
class CryptoManager {
    private val alias = "philasecret_identity_v1"
    private val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    init {
        if (!store.containsAlias(alias)) {
            val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA, "AndroidKeyStore")
            generator.initialize(
                KeyGenParameterSpec.Builder(
                    alias,
                    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
                )
                    .setKeySize(3072)
                    .setDigests(KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA512)
                    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_OAEP)
                    .build()
            )
            generator.generateKeyPair()
        }
    }

    fun publicKeyB64(): String = Base64.getEncoder().encodeToString(store.getCertificate(alias).publicKey.encoded)

    fun encrypt(plainText: String, recipientPublicKeyB64: String): Envelope {
        val aes = KeyGenerator.getInstance("AES").apply { init(256) }.generateKey()
        val iv = ByteArray(12).also { java.security.SecureRandom().nextBytes(it) }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, aes, GCMParameterSpec(128, iv))
        val ciphertext = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))

        val recipientKey: PublicKey = KeyFactory.getInstance("RSA").generatePublic(
            X509EncodedKeySpec(Base64.getDecoder().decode(recipientPublicKeyB64))
        )
        val wrap = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        wrap.init(Cipher.ENCRYPT_MODE, recipientKey)
        val wrappedKey = wrap.doFinal(aes.encoded)

        return Envelope(
            wrappedKey = Base64.getEncoder().encodeToString(wrappedKey),
            iv = Base64.getEncoder().encodeToString(iv),
            ciphertext = Base64.getEncoder().encodeToString(ciphertext)
        )
    }

    fun decrypt(envelope: Envelope): String {
        val privateKey = (store.getEntry(alias, null) as KeyStore.PrivateKeyEntry).privateKey
        val unwrap = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding")
        unwrap.init(Cipher.DECRYPT_MODE, privateKey)
        val aesBytes = unwrap.doFinal(Base64.getDecoder().decode(envelope.wrappedKey))
        val aes = javax.crypto.spec.SecretKeySpec(aesBytes, "AES")

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            aes,
            GCMParameterSpec(128, Base64.getDecoder().decode(envelope.iv))
        )
        return String(cipher.doFinal(Base64.getDecoder().decode(envelope.ciphertext)), StandardCharsets.UTF_8)
    }
}

data class Envelope(val wrappedKey: String, val iv: String, val ciphertext: String)
