package com.philasecret.app

import com.google.gson.Gson
import java.net.HttpURLConnection
import java.net.URL

class ApiClient(private val baseUrl: String) {
    private val gson = Gson()

    fun register(username: String, publicKey: String) = request(
        "POST", "/v1/register", gson.toJson(mapOf("username" to username, "publicKey" to publicKey))
    )

    fun publicKey(username: String): String {
        val body = request("GET", "/v1/keys/${java.net.URLEncoder.encode(username, "UTF-8")}")
        return gson.fromJson(body, Map::class.java)["publicKey"].toString()
    }

    fun send(sender: String, recipient: String, envelope: Envelope, readOnce: Boolean) = request(
        "POST", "/v1/messages",
        gson.toJson(mapOf("sender" to sender, "recipient" to recipient, "envelope" to envelope, "readOnce" to readOnce))
    )

    fun inbox(username: String): List<ServerMessage> {
        val body = request("GET", "/v1/messages/$username")
        val arr = gson.fromJson(body, Array<ServerMessage>::class.java)
        return arr?.toList() ?: emptyList()
    }

    fun delete(id: String) { request("DELETE", "/v1/messages/$id") }

    private fun request(method: String, path: String, body: String? = null): String {
        val c = URL(baseUrl.trimEnd('/') + path).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("Content-Type", "application/json")
        if (body != null) {
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) error("HTTP $code: $text")
        return text
    }
}

data class ServerMessage(
    val id: String,
    val sender: String,
    val recipient: String,
    val envelope: Envelope,
    val readOnce: Boolean,
    val createdAt: String
)
