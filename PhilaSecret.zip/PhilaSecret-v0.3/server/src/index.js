import Fastify from 'fastify';
import rateLimit from '@fastify/rate-limit';
import websocket from '@fastify/websocket';
import pg from 'pg';
import crypto from 'node:crypto';

const app = Fastify({ logger: true, bodyLimit: 2 * 1024 * 1024 });
await app.register(rateLimit, { max: 120, timeWindow: '1 minute' });
await app.register(websocket);
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const clients = new Map();
const b64 = s => Buffer.from(s, 'base64');
const id = () => crypto.randomUUID();

await pool.query(`CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY, username TEXT UNIQUE NOT NULL, public_key TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY, sender_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recipient_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  envelope JSONB NOT NULL, kind TEXT NOT NULL DEFAULT 'text',
  read_once BOOLEAN NOT NULL DEFAULT false, expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), read_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS messages_recipient_created ON messages(recipient_id, created_at);
`);

app.get('/health', async () => ({ ok: true, service: 'philasecret-relay', version: '0.3.0' }));

app.post('/v1/users', async (req, reply) => {
  const { username, publicKey } = req.body || {};
  if (!username || !publicKey || username.length < 3 || username.length > 32) return reply.code(400).send({ error: 'invalid_input' });
  try {
    const r = await pool.query('INSERT INTO users(id,username,public_key) VALUES($1,$2,$3) RETURNING id,username,public_key', [id(), username, publicKey]);
    return r.rows[0];
  } catch { return reply.code(409).send({ error: 'username_taken' }); }
});

app.get('/v1/users/:username/key', async (req, reply) => {
  const r = await pool.query('SELECT id, username, public_key FROM users WHERE username=$1', [req.params.username]);
  if (!r.rowCount) return reply.code(404).send({ error: 'not_found' });
  return r.rows[0];
});

app.post('/v1/messages', async (req, reply) => {
  const { senderId, recipientId, envelope, kind='text', readOnce=false, ttlSeconds=null } = req.body || {};
  if (!senderId || !recipientId || !envelope || typeof envelope !== 'object') return reply.code(400).send({ error: 'invalid_input' });
  const allowed = new Set(['text','image','audio','video']);
  if (!allowed.has(kind)) return reply.code(400).send({ error: 'invalid_kind' });
  const messageId = id();
  const expires = ttlSeconds ? new Date(Date.now() + Math.min(Number(ttlSeconds), 7*24*3600) * 1000) : null;
  const r = await pool.query('INSERT INTO messages(id,sender_id,recipient_id,envelope,kind,read_once,expires_at) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,created_at,expires_at', [messageId,senderId,recipientId,envelope,kind,!!readOnce,expires]);
  const payload = { id: messageId, senderId, recipientId, envelope, kind, readOnce: !!readOnce, createdAt: r.rows[0].created_at, expiresAt: r.rows[0].expires_at };
  clients.get(recipientId)?.forEach(ws => ws.send(JSON.stringify({ type: 'message', message: payload })));
  return payload;
});

app.get('/v1/messages', async (req, reply) => {
  const { recipientId, limit=50 } = req.query;
  if (!recipientId) return reply.code(400).send({ error: 'recipientId_required' });
  const r = await pool.query(`SELECT id,sender_id,recipient_id,envelope,kind,read_once,created_at,expires_at FROM messages WHERE recipient_id=$1 AND (expires_at IS NULL OR expires_at>now()) ORDER BY created_at DESC LIMIT $2`, [recipientId, Math.min(Number(limit)||50,100)]);
  return r.rows;
});

// Atomically consumes a read-once message. The ciphertext is returned once, then the row is deleted.
app.post('/v1/messages/:id/consume', async (req, reply) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await client.query(`DELETE FROM messages WHERE id=$1 AND read_once=true AND (expires_at IS NULL OR expires_at>now()) RETURNING id,sender_id,recipient_id,envelope,kind,created_at`, [req.params.id]);
    if (!r.rowCount) { await client.query('ROLLBACK'); return reply.code(404).send({ error: 'expired_or_already_consumed' }); }
    await client.query('COMMIT');
    return { message: r.rows[0] };
  } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
});

app.post('/v1/messages/:id/read', async (req, reply) => {
  await pool.query('UPDATE messages SET read_at=now() WHERE id=$1', [req.params.id]);
  return { ok: true };
});

app.get('/v1/ws', { websocket: true }, (socket, req) => {
  const userId = req.headers['x-user-id'];
  if (!userId) return socket.close(1008, 'x-user-id required');
  if (!clients.has(userId)) clients.set(userId, new Set());
  clients.get(userId).add(socket);
  socket.on('close', () => clients.get(userId)?.delete(socket));
  socket.send(JSON.stringify({ type: 'ready' }));
});

// Expire old envelopes; the server never sees plaintext.
setInterval(() => pool.query('DELETE FROM messages WHERE expires_at IS NOT NULL AND expires_at<=now()').catch(()=>{}), 30_000).unref();

const port = Number(process.env.PORT || 8080);
app.listen({ host: '0.0.0.0', port });
